package djonas.meme;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import static djonas.meme.MainActivity.EXTRA_CREATOR;
import static djonas.meme.MainActivity.EXTRA_URL;

public class DetailActivity extends AppCompatActivity{
    TextView topText;
    TextView bottomText;
    EditText editTop;
    EditText editBottom;
    ImageView imageView;
    Button load, save;
    String currentImage = "";

    private static final int MY_PERMISSION_REQUEST = 1;
    private static final int RESULT_IMAGE_LOAD = 2;

    private static int RESULT_LOAD_IMAGE =1;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            switch (requestCode){
                case MY_PERMISSION_REQUEST:{
                    if(grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                        if(ContextCompat.checkSelfPermission(DetailActivity.this,
                                android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
                            //do nothing
                        }
                        else {
                            Toast.makeText(this, "No Permission granted!", Toast.LENGTH_LONG).show();
                            finish();
                        }
                        return;
                    }
                }
            }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        if(ContextCompat.checkSelfPermission(DetailActivity.this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(DetailActivity.this,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE)){
                ActivityCompat.requestPermissions(DetailActivity.this,
                        new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSION_REQUEST);
            } else {
                ActivityCompat.requestPermissions(DetailActivity.this,
                        new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSION_REQUEST);
            }
        } else{
            //do nothing
        }


        topText = (TextView) findViewById(R.id.memeTopText);
        bottomText = (TextView) findViewById(R.id.memeBottomText);
        editTop = (EditText) findViewById(R.id.editTop);
        editBottom = (EditText) findViewById(R.id.editBottom);
        imageView = (ImageView) findViewById(R.id.image_view_detail);
        load = (Button) findViewById(R.id.button);
        save = (Button)findViewById(R.id.button2);

        save.setEnabled(false);

        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                topText.setText(editTop.getText().toString());
                bottomText.setText(editBottom.getText().toString());

                editTop.setText("");
                editBottom.setText("");

                save.setEnabled(true);
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View content = findViewById(R.id.lay);
                Bitmap bitmap = getScrenshot(content);
                currentImage = "meme"+ System.currentTimeMillis()+".png";
                store(bitmap,currentImage);
            }
        });
        Intent intent = getIntent();
        String imageUrl = intent.getStringExtra(EXTRA_URL);
        String creatorName = intent.getStringExtra(EXTRA_CREATOR);

        ImageView imageView = (ImageView) findViewById(R.id.image_view_detail);
        TextView textViewCreator = (TextView) findViewById(R.id.text_view_creator_detail);

        Picasso.with(this).load(imageUrl).fit().centerInside().into(imageView);
        textViewCreator.setText(creatorName);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data){
            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));
        }
    }

    public static Bitmap getScrenshot(View view)
    {
        view.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(view.getDrawingCache());
        view.setDrawingCacheEnabled(false);
        return bitmap;
    }

    public void store(Bitmap bm, String filename)
    {
        String dirpath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Meme/";
        File dir = new File(dirpath);
        if(!dir.exists())
        {
            dir.mkdir();
        }
        File file = new File(dirpath,filename);
        try
        {
            FileOutputStream fos = null;
            fos = new FileOutputStream(file);
            bm.compress(Bitmap.CompressFormat.PNG,100,fos);
            fos.flush();
            fos.close();
            Toast.makeText(this,"Saved",Toast.LENGTH_LONG).show();
        }
        catch(FileNotFoundException e)
        {
            Toast.makeText(this,"Error saving!",Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public void saveImage(View view )
    {

    }
}